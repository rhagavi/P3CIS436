//Rhagavi Thiagarajah
package com.example.temperaturedistanceconvertmenu;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import androidx.fragment.app.Fragment;

public class TemperatureFragment extends Fragment{
    //Declared variables to use the components of android
    TextView result;
    EditText inputDegree;
    Button celsiusToFahrenheit;
    Button FahrenheitToCelsius;
    Float result_degree;
    Float input_degree;
    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle instanceState){

        ViewGroup root; //create ViewGroup for displaying layout
        //check the orientation status
        //For Portrait
        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
             root = (ViewGroup) inflater.inflate(R.layout.temperature_fragment, null);
        }

        else  {  //For Landscape
             root = (ViewGroup) inflater.inflate(R.layout.temperature_fragment,null);
        }

        //Connect the components of the android to variables
        result = (TextView)  root.findViewById(R.id.ResultValue); //Display the result
        inputDegree = (EditText)root.findViewById(R.id.inputDegree); //user input the degree
        celsiusToFahrenheit = (Button)root.findViewById(R.id.CtoF); //Button
        FahrenheitToCelsius = (Button)root.findViewById(R.id.FtoC);//Button

        //if user click on this button to convert from celsius to fahrenheit
        celsiusToFahrenheit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Calculate and display the result
                input_degree = Float.parseFloat(inputDegree.getText().toString());
                result_degree = (input_degree *(float)(9.0/5.0)) + 32;
                result.setText(String.valueOf(input_degree)+ " C = "+ String.valueOf(result_degree) + "F");
            }
        });
        //if user click on this button to convert from fahrenheit to celsius
        FahrenheitToCelsius.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Calculate and display the result
                input_degree = Float.parseFloat(inputDegree.getText().toString());
                result_degree = (input_degree - 32) * (float)(5.0/9.0);
                result.setText(String.valueOf(input_degree)+ "F = "+ String.valueOf(result_degree) + "C");
            }
        });
        return root;
    }
}
