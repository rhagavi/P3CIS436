/*
* Name: Rhagavi Thiagarajah
* CIS 436 Project 2
* Professor John Baugh
* March 27, 2020
* */
package com.example.temperaturedistanceconvertmenu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private TemperatureFragment tempfragment;
    private DistanceFragment distFragment;
    private HomeFragment homeFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tempfragment = new TemperatureFragment();
        distFragment = new DistanceFragment();
        homeFragment = new HomeFragment();
        FragmentManager fragmentManager = getSupportFragmentManager();
        //begin placement of the fragment
       FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        //set Home as the default fragment
        //we will use value 0 for the showingFragment (0)
       fragmentTransaction.add(R.id.placeHolderLayout,homeFragment);
        //commit the change
        fragmentTransaction.commit();
    } // end onCreate()

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //display menu options
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    } //end onCreateOptionsMenu

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //If one of the options in the menu selected....
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        if(item.getItemId() == R.id.Temperature) { //Convert Temperature
            Toast.makeText(this, "Convert Temperature", Toast.LENGTH_LONG).show();
            //check the status of the orientation before replacing the fragment with the orientation
            // type.
            if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE
                    || getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
                fragmentTransaction.replace(R.id.placeHolderLayout,tempfragment);
            }

        }
        else if(item.getItemId() == R.id.Distance) { //Convert Distance
            Toast.makeText(this, "Convert Distance", Toast.LENGTH_LONG).show();
            //check the status of the orientation before replacing the fragment with the orientation
            // type.
            if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE
                    || getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
                fragmentTransaction.replace(R.id.placeHolderLayout,distFragment);
            }
        }

        else if(item.getItemId() == R.id.Home) { //Home
            Toast.makeText(this, "Home", Toast.LENGTH_LONG).show();
            //check the status of the orientation before replacing the fragment with the orientation
            // type.
            fragmentTransaction.replace(R.id.placeHolderLayout,homeFragment);
        }
        else {
            return super.onContextItemSelected(item);
        }
        fragmentTransaction.commit();
        return true;
    }//end onOptionsItemSelected


}


