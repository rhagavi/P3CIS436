//Rhagavi Thiagarajah
package com.example.temperaturedistanceconvertmenu;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class DistanceFragment extends Fragment {
    //Declared variables to use the components of android
    TextView result;
    EditText inputDegree;
    Button milesToKilometers;
    Button kmToMiles;
    Float result_degree;
    Float input_degree;
    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle instanceState){

        ViewGroup root; //create ViewGroup for displaying layout
        //Check the orientation status
        //For Portrait
        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
            root = (ViewGroup) inflater.inflate(R.layout.distance_fragment, null);
        }

        else  {  //For Landscape
            root = (ViewGroup) inflater.inflate(R.layout.distance_fragment,null);
        }

        //Connect the components of the android to variables
        result = (TextView)  root.findViewById(R.id.ResultValue); //Display the result
        inputDegree = (EditText)root.findViewById(R.id.inputDegree); //user input the degree
        milesToKilometers = (Button)root.findViewById(R.id.MtoK); //Button
        kmToMiles = (Button)root.findViewById(R.id.KtoM);//Button

        //if user click on this button to convert from miles to kilometers
        milesToKilometers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_degree = Float.parseFloat(inputDegree.getText().toString());
                //Calculate and display the result
                result_degree = input_degree / (float)0.62137;
                result.setText(String.valueOf(input_degree)+ " Miles = "+ String.valueOf(result_degree) + "Km");
            }
        });
        //if user click on this button to convert from fahrenheit to celsius
        kmToMiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_degree = Float.parseFloat(inputDegree.getText().toString());
                //Calculate and display the result
                result_degree = input_degree * (float)0.62137;
                result.setText(String.valueOf(input_degree)+ "Km = "+ String.valueOf(result_degree) + "Miles");
            }
        });

        return root;
    }
}
